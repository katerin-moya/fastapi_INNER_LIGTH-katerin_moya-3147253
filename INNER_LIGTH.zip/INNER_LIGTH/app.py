from fastapi import FastAPI
from routers import usuarios

app = FastAPI(title="API Inner Light")

# Incluir routers
app.include_router(usuarios.router, prefix="/usuarios", tags=["Usuarios"])


