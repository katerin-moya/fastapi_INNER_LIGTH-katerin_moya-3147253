from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional

class Usuario(BaseModel):
    nombre: str
    correo: EmailStr
    password: str
    rol: str = "usuario"
    fecha_creacion: Optional[datetime] = datetime.now()
