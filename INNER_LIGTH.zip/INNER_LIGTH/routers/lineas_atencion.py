from fastapi import APIRouter, HTTPException
from database import db, object_id_str
from bson import ObjectId
from pydantic import BaseModel

class LineaAtencion(BaseModel):
    nombre: str
    telefono: str
    descripcion: str

router = APIRouter(prefix="/lineas", tags=["Líneas de Atención"])

@router.post("/")
async def crear_linea(linea: LineaAtencion):
    nueva = linea.dict()
    result = await db.lineas_atencion.insert_one(nueva)
    return {"id": str(result.inserted_id)}

@router.get("/")
async def listar_lineas():
    lineas = []
    async for l in db.lineas_atencion.find():
        lineas.append(object_id_str(l))
    return lineas

@router.get("/{id}")
async def obtener_linea(id: str):
    if (linea := await db.lineas_atencion.find_one({"_id": ObjectId(id)})) is not None:
        return object_id_str(linea)
    raise HTTPException(404, "Línea no encontrada")

@router.put("/{id}")
async def actualizar_linea(id: str, linea: LineaAtencion):
    result = await db.lineas_atencion.update_one({"_id": ObjectId(id)}, {"$set": linea.dict()})
    if result.modified_count == 1:
        return {"msg": "Línea de atención actualizada"}
    raise HTTPException(404, "Línea no encontrada")

@router.delete("/{id}")
async def eliminar_linea(id: str):
    result = await db.lineas_atencion.delete_one({"_id": ObjectId(id)})
    if result.deleted_count == 1:
        return {"msg": "Línea eliminada"}
    raise HTTPException(404, "Línea no encontrada")


