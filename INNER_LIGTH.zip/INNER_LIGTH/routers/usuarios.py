from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List

router = APIRouter()

# Modelo de usuario
class Usuario(BaseModel):
    id: int
    nombre: str
    email: str

# Base de datos temporal en memoria
usuarios_db: List[Usuario] = []

# Obtener todos los usuarios
@router.get("/", response_model=List[Usuario])
def listar_usuarios():
    return usuarios_db

# Obtener un usuario por ID
@router.get("/{usuario_id}", response_model=Usuario)
def obtener_usuario(usuario_id: int):
    for usuario in usuarios_db:
        if usuario.id == usuario_id:
            return usuario
    raise HTTPException(status_code=404, detail="Usuario no encontrado")

# Crear un usuario
@router.post("/", response_model=Usuario)
def crear_usuario(usuario: Usuario):
    usuarios_db.append(usuario)
    return usuario

# Actualizar un usuario
@router.put("/{usuario_id}", response_model=Usuario)
def actualizar_usuario(usuario_id: int, datos: Usuario):
    for i, usuario in enumerate(usuarios_db):
        if usuario.id == usuario_id:
            usuarios_db[i] = datos
            return datos
    raise HTTPException(status_code=404, detail="Usuario no encontrado")

# Eliminar un usuario
@router.delete("/{usuario_id}")
def eliminar_usuario(usuario_id: int):
    for i, usuario in enumerate(usuarios_db):
        if usuario.id == usuario_id:
            usuarios_db.pop(i)
            return {"mensaje": "Usuario eliminado"}
    raise HTTPException(status_code=404, detail="Usuario no encontrado")
